
const header = document.querySelector('header');

header.addEventListener('click', () => {
  header.style.backgroundColor = 'grey';
});
const form = document.getElementById("booking-form");

form.addEventListener("submit", function(event) {
  event.preventDefault();
  const formData = new FormData(form);
  const data = {};
  for (const [key, value] of formData.entries()) {
    data[key] = value;
  }
  console.log(data);
  // code to send the form data to a server or email it to the business
});



